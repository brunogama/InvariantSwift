# OpenSpec Feature Proposals Pack — More Features (v2)

Copy these into your repo under `openspec/changes/`.

- `openspec/changes/linearizability-testing` — Linearizability testing module for concurrent histories (pbt-linearizability)
- `openspec/changes/coverage-guided-generation` — Coverage-guided generation (opt-in instrumentation) (pbt-coverage-guidance)
- `openspec/changes/mutation-testing-hooks` — Mutation testing hooks (mutant-aware runs) (pbt-mutation)
- `openspec/changes/grammar-based-generators-tree-sitter` — Grammar-based generators using Tree-sitter (opt-in) (pbt-grammar-generators)
- `openspec/changes/regex-string-generators` — Regex-constrained string generators (pbt-generators)
- `openspec/changes/distribution-constraints-quantiles` — Generator distribution constraints (quantiles/percentiles) (pbt-generators)
- `openspec/changes/stateful-precondition-coverage` — Stateful testing: precondition coverage and selection bias (pbt-stateful)
- `openspec/changes/stable-counterexample-formatting` — Stable counterexample formatting and redaction hooks (pbt-reporting)
- `openspec/changes/fuzzing-bridge-api` — Fuzzing bridge API (property -> fuzz harness) (pbt-fuzzing)
- `openspec/changes/shrink-search-strategies` — Pluggable shrink search strategies (BFS/DFS/best-first) (pbt-shrinking)
- `openspec/changes/experimental-feature-gating` — Experimental feature gating and product modularization (pbt-packaging)
- `openspec/changes/shrink-trace-explanations` — Shrink trace and human-readable explanation output (pbt-reporting)
