---
id: shrink-search-strategies
title: Pluggable shrink search strategies (BFS/DFS/best-first)
capability: pbt-shrinking
status: proposed
---

# Pluggable shrink search strategies (BFS/DFS/best-first)

## Summary
Select shrink search strategies with deterministic behavior to trade off speed vs minimality.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-shrinking/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
