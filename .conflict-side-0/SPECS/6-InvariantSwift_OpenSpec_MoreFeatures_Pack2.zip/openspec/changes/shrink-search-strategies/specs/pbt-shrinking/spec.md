# Spec Delta — pbt-shrinking

## ADDED Requirements

### Requirement: SHRINK-STRAT-001 — Strategy selection
The framework MUST allow selecting a shrink search strategy and remain deterministic.

#### Scenario: Strategy affects minimality
- **Given:** a property with many shrink candidates
- **When:** run with DFS vs BFS
- **Then:** both produce failing counterexamples with potentially different minimality/time
