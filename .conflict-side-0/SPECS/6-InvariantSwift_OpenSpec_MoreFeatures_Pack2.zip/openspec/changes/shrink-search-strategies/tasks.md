# Tasks

- [ ] Define ShrinkSearchStrategy protocol and config plumbing
- [ ] Implement BFS (baseline), DFS (fast), BestFirst (heuristic)
- [ ] Ensure determinism: stable candidate ordering and tie-breaking
- [ ] Add tests showing strategies produce failing counterexamples deterministically
- [ ] Document tradeoffs and recommended defaults
