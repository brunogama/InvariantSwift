# Design

## Key decisions
- Default remains BFS for minimality bias
- BestFirst requires deterministic heuristic function

## Open questions
- Add time-budgeted shrink strategy now or separate?
