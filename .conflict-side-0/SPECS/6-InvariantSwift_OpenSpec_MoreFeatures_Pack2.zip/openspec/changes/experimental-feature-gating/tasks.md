# Tasks

- [ ] Define product/module map: Core, Testing, Macros, Generators, Reporting, Experimental/*
- [ ] Move experimental folders into `InvariantExperimental` target(s)
- [ ] Ensure importing Core does not pull SwiftSyntax or heavy deps
- [ ] Add docs: which import provides which features
- [ ] Add build checks to prevent dependency creep
