# Spec Delta — pbt-packaging

## ADDED Requirements

### Requirement: PACK-001 — Core remains lightweight
Core product MUST not depend on macro/tooling packages and should build fast.

#### Scenario: Core builds without SwiftSyntax
- **Given:** a project importing only Core
- **When:** building
- **Then:** SwiftSyntax is not pulled in
