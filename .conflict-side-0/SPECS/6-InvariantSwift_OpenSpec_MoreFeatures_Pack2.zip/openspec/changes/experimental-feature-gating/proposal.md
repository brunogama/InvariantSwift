---
id: experimental-feature-gating
title: Experimental feature gating and product modularization
capability: pbt-packaging
status: proposed
---

# Experimental feature gating and product modularization

## Summary
Gate advanced modules behind separate products and explicit imports to keep core lightweight and stable.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-packaging/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
