# Design

## Key decisions
- Core remains dependency-free beyond stdlib/Foundation
- Experimental APIs are marked and can change faster

## Open questions
- Meta-product that re-exports everything for internal use?
