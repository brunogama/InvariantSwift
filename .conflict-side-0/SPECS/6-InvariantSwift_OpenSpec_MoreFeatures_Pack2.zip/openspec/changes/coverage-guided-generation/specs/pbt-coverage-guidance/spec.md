# Spec Delta — pbt-coverage-guidance

## ADDED Requirements

### Requirement: COVG-001 — Instrumentation API
The framework MUST allow users to emit coverage signals during predicate evaluation.

#### Scenario: Record signals
- **Given:** a predicate that emits signals
- **When:** run
- **Then:** signals are recorded per iteration

### Requirement: COVG-002 — Guided biasing
When guidance is enabled, the framework MUST bias future generation toward novel or rare signals.

#### Scenario: Rare path found faster
- **Given:** a rare-branch predicate
- **When:** run with guidance vs without
- **Then:** guided run discovers the rare branch in fewer iterations on average (benchmarked)
