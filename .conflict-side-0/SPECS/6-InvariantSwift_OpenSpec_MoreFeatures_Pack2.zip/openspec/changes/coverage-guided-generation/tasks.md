# Tasks

- [ ] Define CoverageSignal protocol (signal IDs + optional numeric score)
- [ ] Add RunnerConfig.coverageGuidance knobs (exploration/exploitation)
- [ ] Implement guided selection: track novelty set and reward rare signals
- [ ] Add deterministic tie-breaking for guidance decisions
- [ ] Add example: rare-branch predicate; demonstrate improved discovery
- [ ] Add tests validating determinism for same seed + signals
