---
id: coverage-guided-generation
title: Coverage-guided generation (opt-in instrumentation)
capability: pbt-coverage-guidance
status: proposed
---

# Coverage-guided generation (opt-in instrumentation)

## Summary
Add opt-in coverage guidance using user-provided instrumentation signals to bias generation toward novel paths.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-coverage-guidance/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
