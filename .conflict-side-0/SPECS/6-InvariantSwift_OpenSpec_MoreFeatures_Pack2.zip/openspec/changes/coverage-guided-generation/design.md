# Design

## Key decisions
- Signals are user instrumentation (no toolchain coverage integration in core)
- Guidance is opt-in and must not affect semantics when disabled
- Determinism via seed-splitting + stable ordering of signals

## Open questions
- Guidance state per-property vs global suite?
- Persist guidance state in regression bank?
