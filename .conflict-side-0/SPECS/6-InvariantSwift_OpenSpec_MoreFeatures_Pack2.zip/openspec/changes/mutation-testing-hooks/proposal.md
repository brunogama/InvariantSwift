---
id: mutation-testing-hooks
title: Mutation testing hooks (mutant-aware runs)
capability: pbt-mutation
status: proposed
---

# Mutation testing hooks (mutant-aware runs)

## Summary
Add hooks to integrate mutation testing by running the same property suite against a mutant build and recording killed/survived mutants with replay tokens.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-mutation/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
