# Design

## Key decisions
- Framework provides hooks and reporting; does not implement a full mutation engine
- Replay tokens are required for each killed mutant to reproduce

## Open questions
- CLI driver for mutant runs vs API-only?
