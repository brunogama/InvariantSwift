# Tasks

- [ ] Define MutantDescriptor model (id, description, source location)
- [ ] Add Runner API: runSuite(mutant:) that tags outputs with mutant ID
- [ ] Add report fields: killed/survived + firstKillReplayToken
- [ ] Add example integration stub (no external mutation engine required)
- [ ] Add tests simulating mutants by swapping implementations
