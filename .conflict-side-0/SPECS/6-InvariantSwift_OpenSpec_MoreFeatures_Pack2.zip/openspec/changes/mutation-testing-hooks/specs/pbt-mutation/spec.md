# Spec Delta — pbt-mutation

## ADDED Requirements

### Requirement: MUT-001 — Mutant-aware reporting
The framework MUST support tagging a run with a mutant ID and reporting whether the mutant was killed.

#### Scenario: Killed mutant
- **Given:** a mutant that breaks a law
- **When:** properties are run against it
- **Then:** the report marks the mutant as killed and includes a replay token
