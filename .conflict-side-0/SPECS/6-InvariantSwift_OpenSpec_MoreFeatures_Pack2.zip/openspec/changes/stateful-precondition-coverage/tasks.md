# Tasks

- [ ] Instrument precondition evaluation counts per command type
- [ ] Add selection bias option: prefer commands with low enabled rate
- [ ] Add reporting: per-command enabled %, executed %, discarded %
- [ ] Add tests verifying deterministic bias decisions
- [ ] Add example where rare command becomes covered
