# Spec Delta — pbt-stateful

## ADDED Requirements

### Requirement: STATE-PRE-001 — Precondition coverage reporting
The framework MUST report command precondition enabled/executed rates for stateful tests.

#### Scenario: Reports command rates
- **Given:** a state machine with multiple commands
- **When:** run
- **Then:** a report contains enabled/executed/discarded percentages per command
