---
id: stateful-precondition-coverage
title: Stateful testing: precondition coverage and selection bias
capability: pbt-stateful
status: proposed
---

# Stateful testing: precondition coverage and selection bias

## Summary
Track command precondition hit rates and optionally bias command selection to cover rarely-enabled commands.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-stateful/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
