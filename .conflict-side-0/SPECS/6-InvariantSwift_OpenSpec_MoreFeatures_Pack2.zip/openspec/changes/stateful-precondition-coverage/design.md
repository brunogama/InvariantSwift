# Design

## Key decisions
- Bias is opt-in and deterministic
- Reports integrate with JSON schema when enabled

## Open questions
- Bias also consider postcondition failure rates?
