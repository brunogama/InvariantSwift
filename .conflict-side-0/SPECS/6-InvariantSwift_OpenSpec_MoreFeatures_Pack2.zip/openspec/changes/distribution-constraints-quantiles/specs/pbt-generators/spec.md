# Spec Delta — pbt-generators

## ADDED Requirements

### Requirement: DIST-001 — Quantile constraints
The framework MUST allow defining quantile constraints and validating them deterministically.

#### Scenario: Quantile enforced
- **Given:** a size generator with 90th percentile constraint
- **When:** validated
- **Then:** the framework reports pass/fail and prints observed quantiles
