# Tasks

- [ ] Define DistributionConstraint API (quantiles, mean bounds, category ratios)
- [ ] Add runner validation mode: sample distribution and fail/warn on violations
- [ ] Add reporting: observed quantiles and histogram buckets
- [ ] Add tests with deterministic sampling
- [ ] Add example: mostly-small array sizes with occasional large cases
