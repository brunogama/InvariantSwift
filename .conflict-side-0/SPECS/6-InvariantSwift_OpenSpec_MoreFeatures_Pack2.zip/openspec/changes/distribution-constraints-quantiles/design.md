# Design

## Key decisions
- Distribution validation is optional and separate from predicate truth
- Sampling for validation uses deterministic seeds and fixed sample size

## Open questions
- Distribution violations: failure vs warning default?
