# Design

## Key decisions
- No dependency on libFuzzer; output is a Swift callable entrypoint
- Byte decoding is total and deterministic

## Open questions
- Generate harness stubs via CLI or API-only?
