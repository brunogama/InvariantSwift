---
id: fuzzing-bridge-api
title: Fuzzing bridge API (property -> fuzz harness)
capability: pbt-fuzzing
status: proposed
---

# Fuzzing bridge API (property -> fuzz harness)

## Summary
Provide a bridge: map bytes to generated values deterministically and expose a harness entrypoint for fuzz engines (without bundling a fuzzer).

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-fuzzing/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
