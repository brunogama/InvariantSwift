# Tasks

- [ ] Define FuzzHarness API: map bytes -> value (total, never traps)
- [ ] Provide ByteGen utilities and deterministic decoding
- [ ] Expose a harness function suitable for libFuzzer-style entrypoints
- [ ] Add example harness for JSON decoder
- [ ] Add tests for determinism of byte decoding
