# Spec Delta — pbt-fuzzing

## ADDED Requirements

### Requirement: FZ-001 — Byte decoding determinism
The framework MUST provide deterministic decoding from input bytes to generated values.

#### Scenario: Same bytes -> same value
- **Given:** a fixed byte array
- **When:** decoded twice
- **Then:** the generated value is identical
