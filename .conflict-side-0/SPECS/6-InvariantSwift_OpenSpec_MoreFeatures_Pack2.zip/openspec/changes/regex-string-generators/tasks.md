# Tasks

- [ ] Define RegexGen API using Swift Regex where available
- [ ] Implement generator by building from regex AST (avoid rejection sampling)
- [ ] Implement shrinker that preserves match: shorten repetitions, simplify alternations, shrink character classes
- [ ] Add tests for determinism and match correctness
- [ ] Add example usage in README/spec examples
