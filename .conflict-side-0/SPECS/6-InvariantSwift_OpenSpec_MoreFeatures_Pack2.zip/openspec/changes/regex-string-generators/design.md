# Design

## Key decisions
- Avoid rejection sampling to prevent discard explosions
- Prefer Swift Regex AST when supported by toolchain

## Open questions
- Support full regex features or a safe subset first?
