---
id: regex-string-generators
title: Regex-constrained string generators
capability: pbt-generators
status: proposed
---

# Regex-constrained string generators

## Summary
Generate strings matching a regular expression with deterministic shrinking that preserves the regex constraint.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-generators/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
