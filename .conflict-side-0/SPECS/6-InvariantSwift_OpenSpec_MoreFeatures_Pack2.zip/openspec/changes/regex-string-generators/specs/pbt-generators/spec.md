# Spec Delta — pbt-generators

## ADDED Requirements

### Requirement: REGEX-001 — Regex-constrained generation
The framework MUST generate strings that match the provided regex.

#### Scenario: Matches regex
- **Given:** a regex for `[a-z]{3}[0-9]{2}`
- **When:** sampling values
- **Then:** every sample matches the regex
