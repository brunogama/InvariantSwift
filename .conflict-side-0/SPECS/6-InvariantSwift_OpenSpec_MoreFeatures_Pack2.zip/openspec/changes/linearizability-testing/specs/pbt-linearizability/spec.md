# Spec Delta — pbt-linearizability

## ADDED Requirements

### Requirement: LIN-001 — History model
The framework MUST represent concurrent histories as invocation/response events grouped by thread.

#### Scenario: Build history
- **Given:** operations executed by two threads
- **When:** events are recorded
- **Then:** the history is representable and serializable

### Requirement: LIN-002 — Linearizability check
The framework MUST determine whether a history is linearizable with respect to a sequential specification.

#### Scenario: Detect non-linearizable
- **Given:** a known non-linearizable history
- **When:** checked
- **Then:** the result is failure with a minimal counterexample history
