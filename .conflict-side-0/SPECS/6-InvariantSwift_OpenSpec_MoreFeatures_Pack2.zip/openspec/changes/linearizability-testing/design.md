# Design

## Key decisions
- Module is opt-in; core remains dependency-free
- History shrink order: remove operations first, then shrink payloads
- Checker is deterministic for the same history input

## Open questions
- Require a sequential specification protocol vs closure API?
- Export DOT/mermaid history visualization?
