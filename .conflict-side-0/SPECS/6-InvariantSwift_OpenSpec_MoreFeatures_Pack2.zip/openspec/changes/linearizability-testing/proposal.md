---
id: linearizability-testing
title: Linearizability testing module for concurrent histories
capability: pbt-linearizability
status: proposed
---

# Linearizability testing module for concurrent histories

## Summary
Add a linearizability checker for concurrent operation histories with shrinking of histories and clear counterexample visualization.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-linearizability/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
