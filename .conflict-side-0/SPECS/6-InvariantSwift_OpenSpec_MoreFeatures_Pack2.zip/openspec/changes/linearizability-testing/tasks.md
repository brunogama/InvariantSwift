# Tasks

- [ ] Introduce new target/module `InvariantLinearizability` (opt-in)
- [ ] Define History model: threads, events (invoke/return), operation IDs, order metadata
- [ ] Implement linearizability check with pruning and deterministic search
- [ ] Implement history shrinker (remove operations, then shrink payloads)
- [ ] Add example: concurrent stack/counter; add tests for known histories
- [ ] Add report output: minimal history + suggested interleaving
