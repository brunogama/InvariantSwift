---
id: shrink-trace-explanations
title: Shrink trace and human-readable explanation output
capability: pbt-reporting
status: proposed
---

# Shrink trace and human-readable explanation output

## Summary
Record an optional shrink trace (why each step was chosen) and emit a concise explanation for debugging and LLM consumption.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-reporting/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
