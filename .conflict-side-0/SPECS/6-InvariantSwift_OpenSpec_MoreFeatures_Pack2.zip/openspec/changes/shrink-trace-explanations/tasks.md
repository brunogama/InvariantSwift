# Tasks

- [ ] Define ShrinkTrace model (step, candidate, reason, elapsed)
- [ ] Record trace optionally during shrinking (config flag)
- [ ] Emit trace in JSON report and human-readable summary
- [ ] Add tests ensuring trace determinism
- [ ] Add example output for array shrinking
