# Design

## Key decisions
- Trace recording is opt-in to avoid perf overhead
- Trace format is stable and versioned

## Open questions
- Include trace in replay token (size concerns)?
