# Spec Delta — pbt-reporting

## ADDED Requirements

### Requirement: TRACE-001 — Shrink trace recording
When enabled, the framework MUST record a deterministic shrink trace and include it in reports.

#### Scenario: Trace included
- **Given:** a failing run with trace enabled
- **When:** report emitted
- **Then:** report includes ordered shrink steps and reasons
