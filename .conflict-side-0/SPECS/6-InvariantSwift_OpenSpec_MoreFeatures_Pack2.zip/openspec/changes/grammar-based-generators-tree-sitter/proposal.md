---
id: grammar-based-generators-tree-sitter
title: Grammar-based generators using Tree-sitter (opt-in)
capability: pbt-grammar-generators
status: proposed
---

# Grammar-based generators using Tree-sitter (opt-in)

## Summary
Add grammar-based generators for structured text using Tree-sitter grammars, with shrinking via AST edits.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-grammar-generators/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
