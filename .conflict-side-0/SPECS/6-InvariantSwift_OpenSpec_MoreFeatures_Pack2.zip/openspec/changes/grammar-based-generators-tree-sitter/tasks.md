# Tasks

- [ ] Introduce optional module `InvariantGrammarGenerators` (Tree-sitter dependencies)
- [ ] Define GrammarGen API: generate AST then render to text
- [ ] Implement AST-aware shrinker: delete nodes, simplify literals, reduce lists
- [ ] Provide built-in grammars for JSON and a small expression grammar
- [ ] Add tests: generated text parses; shrinking preserves parseability
- [ ] Add example: fuzz a JSON decoder with valid JSON only
