# Spec Delta — pbt-grammar-generators

## ADDED Requirements

### Requirement: GRAM-001 — Valid structured text
The framework MUST generate structured text that conforms to a grammar and remains valid under shrinking.

#### Scenario: Valid JSON stays valid
- **Given:** a JSON grammar generator
- **When:** shrinking runs
- **Then:** all shrink candidates remain valid JSON
