# Design

## Key decisions
- Module is opt-in to avoid heavy deps in core
- Shrinkers must preserve grammar validity (parseability)
- Deterministic generation given seed and grammar version

## Open questions
- Pluggable grammars from user bundles vs baked-in only?
