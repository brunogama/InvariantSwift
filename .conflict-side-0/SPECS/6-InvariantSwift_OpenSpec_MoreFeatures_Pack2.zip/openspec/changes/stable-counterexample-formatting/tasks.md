# Tasks

- [ ] Define CounterexampleFormatter protocol with stable defaults
- [ ] Add redaction rules API applied to printed output and JSON reports
- [ ] Add snapshot tests for formatting stability
- [ ] Add example showing redaction of tokens/emails
