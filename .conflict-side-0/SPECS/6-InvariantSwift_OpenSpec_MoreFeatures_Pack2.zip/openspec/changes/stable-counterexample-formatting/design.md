# Design

## Key decisions
- Formatting is deterministic and independent of dictionary hashing
- Redaction occurs at formatting time, not generation time

## Open questions
- Redaction apply to replay token payloads?
