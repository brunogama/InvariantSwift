# Spec Delta — pbt-reporting

## ADDED Requirements

### Requirement: REP-001 — Stable formatting
The framework MUST produce stable, snapshot-friendly counterexample formatting.

#### Scenario: Stable output
- **Given:** a counterexample involving dictionaries
- **When:** rendered twice
- **Then:** the output is identical

### Requirement: REP-002 — Redaction
The framework MUST allow redacting sensitive substrings from printed and JSON-reported outputs.

#### Scenario: Secrets redacted
- **Given:** a counterexample containing 'API_KEY=...'
- **When:** formatted with redaction rules
- **Then:** the secret is masked
