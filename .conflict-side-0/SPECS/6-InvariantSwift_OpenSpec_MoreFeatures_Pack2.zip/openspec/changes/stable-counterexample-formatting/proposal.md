---
id: stable-counterexample-formatting
title: Stable counterexample formatting and redaction hooks
capability: pbt-reporting
status: proposed
---

# Stable counterexample formatting and redaction hooks

## Summary
Deterministic, snapshot-friendly formatting for counterexamples plus redaction hooks to avoid leaking sensitive data.

## Motivation
- Increase practical adoption: better generators, reporting, and ergonomics.
- Add advanced verification features in opt-in modules without compromising core determinism.

## Scope
- Implement requirements in the spec delta under `specs/pbt-reporting/spec.md`.
- Add tests for all scenarios; add example usage where relevant.

## Non-goals
- No breaking changes unless explicitly stated in the delta.
- No new runtime dependencies in core targets.

## Acceptance
- All scenarios in the delta pass.
- Deterministic results for same seed/token across supported platforms.
