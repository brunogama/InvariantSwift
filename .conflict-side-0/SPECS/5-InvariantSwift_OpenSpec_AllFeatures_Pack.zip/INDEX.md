# OpenSpec Feature Proposals Pack

- `openspec/changes/async-throws-predicate-runner` — Async and throwing predicates in Property/Runner (pbt-core)
- `openspec/changes/timeouts-cancellation` — Timeouts and cooperative cancellation (pbt-core)
- `openspec/changes/parallel-checking` — Parallel checking with stable seeding (pbt-core)
- `openspec/changes/seed-splitting-spec` — Seed splitting and replay token schema (v1) (pbt-replay)
- `openspec/changes/collection-shrinking-v2` — Collection shrinking v2: chunk removal first (pbt-shrinking)
- `openspec/changes/float-generation-shrinking` — Float/Double generation and shrinking (robust modes) (pbt-generators)
- `openspec/changes/crash-isolation-macos-subprocess` — Crash isolation on macOS via subprocess runner (pbt-core)
- `openspec/changes/json-report-schema` — Versioned JSON report schema for CI (pbt-core)
- `openspec/changes/property-combinators` — Property combinators: and/or/implies (pbt-core)
- `openspec/changes/stateful-command-shrinking` — Stateful testing: shrink command sequences (pbt-stateful)
