# Tasks

- [ ] Add opt-in runner mode: subprocess isolation (macOS only)
- [ ] Define IPC protocol for evaluation requests/responses
- [ ] Make shrinking deterministic by replaying candidates in subprocess
- [ ] Add integration test that triggers fatalError and confirms parent survives
- [ ] Document limitations and platform support
