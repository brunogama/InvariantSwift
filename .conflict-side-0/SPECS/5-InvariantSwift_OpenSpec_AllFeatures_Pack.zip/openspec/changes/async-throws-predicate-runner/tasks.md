# Tasks

- [ ] Add predicate overloads on Property (sync/throws/async/asyncThrows)
- [ ] Update PropertyRunner to execute each predicate kind and normalize outcomes
- [ ] Make FailureReason.threwError reachable and stable (string formatting rules)
- [ ] Add tests: sync success/fail, throws, async success/fail, async throws
- [ ] Update macros to target correct runner entrypoints
