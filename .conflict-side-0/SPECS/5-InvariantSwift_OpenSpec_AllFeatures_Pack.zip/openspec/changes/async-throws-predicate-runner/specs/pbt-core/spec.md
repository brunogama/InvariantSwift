# Spec Delta — pbt-core

## ADDED Requirements

### Requirement: CORE-ASYNC-001 — Async predicates
The framework MUST support properties with `async` predicates.

#### Scenario: Async pass
- **Given:** an async predicate that returns true for all generated values
- **When:** executed
- **Then:** the run succeeds

#### Scenario: Async fail shrinks
- **Given:** an async predicate that returns false for some value
- **When:** executed
- **Then:** the run reports a minimal counterexample and replay token

### Requirement: CORE-THROW-001 — Throwing predicates
The framework MUST treat thrown errors as failures and report them deterministically.

#### Scenario: Throw captured
- **Given:** a throwing predicate that throws for some value
- **When:** executed
- **Then:** the run fails with reason `threwError` and includes the error description
