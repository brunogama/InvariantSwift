# Design

## Key decisions
- Prefer additive overloads to avoid breaking API for MVP users
- Errors are rendered with a stable, user-extensible formatter hook

## Open questions
- Should async properties require availability guards on older toolchains?
