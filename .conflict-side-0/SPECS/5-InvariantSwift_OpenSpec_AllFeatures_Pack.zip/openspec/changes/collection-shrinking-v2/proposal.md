---
id: collection-shrinking-v2
title: Collection shrinking v2: chunk removal first
capability: pbt-shrinking
status: proposed
---

# Collection shrinking v2: chunk removal first

## Summary
Improve collection shrinking by deleting chunks (delta-debugging) before element-level shrinking; stabilize dict/set ordering.

## Motivation
- Improve correctness, determinism, and developer trust.
- Keep the PBT core contract sound before adding “advanced” features.

## Scope
- Implement requirements in the spec delta under `specs/pbt-shrinking/spec.md`.
- Add tests for all scenarios and edge cases.

## Non-goals
- No unrelated refactors.
- No expanding to additional features not listed in the delta.

## Acceptance
- All scenarios in the delta pass.
- Deterministic output for the same seed/replay token across supported platforms/toolchains.
