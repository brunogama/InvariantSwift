# Tasks

- [ ] Add Array shrink strategy: chunk deletions (largest-first), then element shrink
- [ ] Add Dictionary shrink: remove key subsets (stable key ordering), then shrink values
- [ ] Define deterministic candidate ordering rules in shrinkers
- [ ] Add tests for minimality and deterministic candidate sequence
- [ ] Benchmark shrinking to avoid pathological blowups
