# Tasks

- [ ] Add Float/Double generator modes: finiteOnly, allowInfinity, allowNaN
- [ ] Implement shrinkers that converge to 0 with deterministic steps
- [ ] Add tolerance helpers for approximate comparisons (where appropriate)
- [ ] Add cross-platform determinism tests
- [ ] Document caveats (NaN comparisons, signed zero)
