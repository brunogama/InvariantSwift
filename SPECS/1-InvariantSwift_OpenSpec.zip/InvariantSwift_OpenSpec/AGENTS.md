# AGENTS.md (managed)

This repository uses an OpenSpec-compatible spec-driven workflow.

## How to work in this repo

1. Read `openspec/AGENTS.md` (authoritative workflow + conventions).
2. Read `openspec/project.md` (project context and constraints).
3. Make changes by creating/updating a folder under `openspec/changes/<change-id>/`.
4. Keep specs under `openspec/specs/` as the current truth.

If you are an AI coding assistant: follow `openspec/AGENTS.md` exactly.
