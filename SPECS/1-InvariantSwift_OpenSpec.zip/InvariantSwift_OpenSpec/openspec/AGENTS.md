# OpenSpec Agent Instructions (InvariantSwift)

## Workflow

OpenSpec uses two main areas:

- `openspec/specs/` — the current system truth.
- `openspec/changes/<change-id>/` — a proposed change: proposal + tasks + spec deltas.

When asked to implement work:

1. Identify (or create) the correct `openspec/changes/<change-id>/` folder.
2. Read:
   - `openspec/project.md`
   - `openspec/specs/**/spec.md` for impacted areas
   - `openspec/changes/<change-id>/proposal.md`
   - `openspec/changes/<change-id>/tasks.md`
   - `openspec/changes/<change-id>/specs/**/spec.md` (deltas)
3. Implement tasks in order, checking off items in `tasks.md`.
4. Keep behavior deterministic and testable.
5. When complete, merge deltas into `openspec/specs/` (current truth) and move the change folder to `openspec/archive/`.

## Spec writing conventions

- Use requirements with MUST/SHALL language.
- Each requirement MUST include at least one scenario.
- Use this structure:

  - `### Requirement: <name>`
  - Requirement statement (MUST/SHALL)
  - `#### Scenario: <name>` with bullet steps:
    - WHEN ...
    - THEN ...

## Delta conventions

Change deltas are patch-like docs that describe what is added/modified/removed relative to the current spec.
Use:

- `## ADDED Requirements`
- `## MODIFIED Requirements`
- `## REMOVED Requirements`

## Output hygiene

- Prefer small, reviewable commits.
- Avoid broad refactors unless explicitly required by a spec.
- Do not invent new public API without adding a spec requirement + scenario.
