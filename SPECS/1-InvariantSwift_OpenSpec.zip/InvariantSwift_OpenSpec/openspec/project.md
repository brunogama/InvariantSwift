# Project Context

## Overview

InvariantSwift is a Swift Package Manager (SPM) property-based / functional testing framework.
It includes:

- A main library target: `InvariantSwift`
- Macro implementations: `InvariantSwiftMacros`
- A CLI runner: `FuncTestCLI`
- SPM plugins: `InvariantSwiftPlugin`, `GhostwriterPlugin`

## Goals

- Deterministic, reproducible property-based testing.
- A clear runner contract: assumptions/discards, gaveUp, shrinking, replay.
- Strong ergonomics via Swift macros.
- Strict concurrency and “warnings as errors” build settings.

## Non-goals

- Competing with full-blown QuickCheck/Hedgehog feature parity in v1.
- Non-deterministic fuzzing.

## Technical constraints

- Swift tools version: 6.1
- Strict concurrency enabled.
- Avoid undefined behavior; eliminate crash hazards (force unwraps, unsafe casts) in core execution paths.

## Public API stability policy

- Changes to user-facing APIs MUST be captured in `openspec/specs/**/spec.md` and in the relevant change delta.
- Keep source-compatible changes preferred; breaking changes require explicit justification in proposal.md.

## Testing policy

- Add unit tests for core runner semantics.
- Add macro tests for all generated code paths.
- Prefer deterministic tests; avoid flaky timing assertions.

## Definition of Done (for a change)

- All tasks in `openspec/changes/<change-id>/tasks.md` are checked off.
- Specs are updated and consistent.
- Tests pass.
- Repro instructions exist for failures (seed/replay token).
