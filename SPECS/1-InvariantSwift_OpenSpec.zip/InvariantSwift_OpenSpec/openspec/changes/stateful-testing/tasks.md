# Tasks: Stateful/model-based testing: command sequences, model transitions, and shrinking

Change-ID: `stateful-testing`

## Story checklist
- [ ] 1. S080 — Implement minimal stateful/model-based testing DSL with shrinking command sequences

## Story details
### S080: Implement minimal stateful/model-based testing DSL with shrinking command sequences

Acceptance criteria:
- Example: stack model vs implementation catches a seeded bug and shrinks to a short command sequence.
- Shrunk command sequences are deterministic and readable.

Tests to add/update:
- Example test suite for stack/queue.
- Determinism test for shrinking command sequences.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
