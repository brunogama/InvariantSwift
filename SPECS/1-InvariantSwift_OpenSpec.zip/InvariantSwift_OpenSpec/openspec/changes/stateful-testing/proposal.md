# Proposal: Stateful/model-based testing: command sequences, model transitions, and shrinking

Change-ID: `stateful-testing`
Epic: `E080`

## Problem
Stateful systems are where PBT provides the biggest leverage. Without a guided state-machine DSL, users reimplement the same patterns.

## Goal
- Provide a minimal model-based testing API: commands with preconditions, next-state transitions, and postconditions.
- Ensure command sequences shrink effectively.

## Success metrics
- Example suite can test a simple reference model vs SUT (e.g., stack/queue) and shrinks failing command sequences to small, readable traces.

## Stories
- S080 Stateful DSL

## References
- Current spec(s):
  - `openspec/specs/stateful-testing/spec.md`
- Change deltas:
  - `openspec/changes/stateful-testing/specs/stateful-testing/spec.md`
