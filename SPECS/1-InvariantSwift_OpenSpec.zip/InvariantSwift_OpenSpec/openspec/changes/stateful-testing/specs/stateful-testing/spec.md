# Delta for Stateful Testing

## ADDED Requirements
### Requirement: Stateful DSL
The system MUST provide a stateful testing DSL with explicit model state and command generation.

#### Scenario: Stateful DSL works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Invariant checking
The harness MUST validate invariants after every command and during shrinking.

#### Scenario: Invariant checking works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
