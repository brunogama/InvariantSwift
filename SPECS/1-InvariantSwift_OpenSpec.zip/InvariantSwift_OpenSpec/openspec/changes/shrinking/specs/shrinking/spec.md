# Delta for Shrinking

## ADDED Requirements
### Requirement: ShrinkTree structure
The shrinker MUST produce a deterministic ShrinkTree for any generated value.

#### Scenario: ShrinkTree structure works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Deterministic shrink search
The shrink search MUST be deterministic and reproducible given the same replay token.

#### Scenario: Deterministic shrink search works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
