# Proposal: Shrinking foundation: ShrinkTree and deterministic minimization

Change-ID: `shrinking`
Epic: `E020`

## Problem
Shrinking is incomplete and unreliable for dependent generators. Key shrink combinators are incorrect or stubbed, and the shrink search strategy is greedy and may produce non-minimal counterexamples.

## Goal
- Introduce a structured representation of shrink candidates (ShrinkTree/RoseTree).
- Implement a deterministic shrink search strategy (BFS or best-first) that consistently finds smaller counterexamples.
- Provide high-quality shrinkers for core Swift types and common composites.

## Out of scope
- Coverage-guided generation (if ever reintroduced, it must be explicit and experimental).

## Success metrics
- For a representative suite of properties, shrinking reduces counterexamples to a stable minimal form.
- Determinism tests prove shrink order and final counterexample are stable given the same seed/config.

## Stories
- S020 Introduce ShrinkTree
- S021 Deterministic shrink search
- S022 Core shrinkers
- S023 Collection chunk-removal shrinking
- S024 Gen.flatMap shrinking

## Notes for implementers (LLM/human)
- Define a “smaller-than” ordering per type (even if approximate) and ensure shrink steps are monotonic under that ordering.
- Never use unsafe casts in shrink logic.

## References
- Current spec(s):
  - `openspec/specs/shrinking/spec.md`
- Change deltas:
  - `openspec/changes/shrinking/specs/shrinking/spec.md`
