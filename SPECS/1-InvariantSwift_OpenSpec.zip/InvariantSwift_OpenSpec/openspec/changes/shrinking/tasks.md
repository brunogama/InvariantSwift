# Tasks: Shrinking foundation: ShrinkTree and deterministic minimization

Change-ID: `shrinking`

## Story checklist
- [ ] 1. S020 — Introduce ShrinkTree (RoseTree) representation for structured shrinking
- [ ] 2. S021 — Implement deterministic shrink search (BFS / best-first) over ShrinkTree
- [ ] 3. S022 — Implement high-quality shrinkers for core Swift types
- [ ] 4. S023 — Add chunk-removal shrinking for arrays and strings (delta debugging style)
- [ ] 5. S024 — Correct Gen.flatMap shrinking using ShrinkTree and seed splitting

## Story details
### S020: Introduce ShrinkTree (RoseTree) representation for structured shrinking

Acceptance criteria:
- ShrinkTree exists in Core and is covered by unit tests.
- Existing shrinkers can be adapted or wrapped to produce ShrinkTree.
- ShrinkTree traversal order is defined and deterministic.

Tests to add/update:
- Unit test: map preserves shape and transforms values.
- Unit test: traversal order is deterministic.

### S021: Implement deterministic shrink search (BFS / best-first) over ShrinkTree

Acceptance criteria:
- The shrinker yields the same minimal counterexample for repeated runs with the same seed/config.
- The strategy is selectable (even if only internally) without changing public API.

Tests to add/update:
- Regression test: a property with multiple shrink paths converges to a known minimal counterexample.
- Determinism test: run shrink twice and compare outputs.

### S022: Implement high-quality shrinkers for core Swift types

Acceptance criteria:
- Shrinking an Int failure consistently converges to a small absolute value.
- Shrinking a String failure reduces length and simplifies characters.
- Shrinking arrays/dicts removes chunks before element-level shrinking.
- All shrinkers produce deterministic candidate ordering.

Tests to add/update:
- Property tests for shrink monotonicity per type.
- Determinism tests (same input => same shrink candidates in same order).

### S023: Add chunk-removal shrinking for arrays and strings (delta debugging style)

Acceptance criteria:
- Arrays shrink by removing chunks before shrinking elements.
- Strings shrink by removing substrings before shrinking characters.

Tests to add/update:
- Unit test: a failing array property shrinks to a minimal-length failing array.
- Unit test: a failing string property shrinks length-first.

### S024: Correct Gen.flatMap shrinking using ShrinkTree and seed splitting

Acceptance criteria:
- Values produced by flatMap shrink in both outer and inner dimensions.
- Shrink output is deterministic across runs.

Tests to add/update:
- Unit test: a flatMap-generated composite structure shrinks to a small counterexample.
- Determinism test: repeated runs shrink to the same minimal counterexample.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
