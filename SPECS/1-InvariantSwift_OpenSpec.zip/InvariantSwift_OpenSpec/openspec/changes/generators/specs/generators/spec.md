# Delta for Generators

## ADDED Requirements
### Requirement: Domain generator pack
The library MUST ship a standard set of generators for common Swift types.

#### Scenario: Domain generator pack works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Shrinker pairing
Every provided generator MUST have an associated shrinker.

#### Scenario: Shrinker pairing works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
