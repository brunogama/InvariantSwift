# Proposal: Generators library: practical domain generators as an optional module

Change-ID: `generators`
Epic: `E070`

## Problem
Adoption increases when a PBT framework ships a practical library of generators (email, URL, UUID, names, etc.). However, these should not bloat the core runtime.

## Goal
- Provide an optional target containing domain generators and shrinkers that are deterministic and well-tested.
- Keep Core free of heavy data tables or locale-specific dependencies.

## Success metrics
- Users can import the domain generator module without affecting users who only want Core.
- Generator outputs match basic validity invariants (e.g., generated emails pass a simple validator).

## Stories
- S070 Domain generators pack

## References
- Current spec(s):
  - `openspec/specs/generators/spec.md`
- Change deltas:
  - `openspec/changes/generators/specs/generators/spec.md`
