# Tasks: Generators library: practical domain generators as an optional module

Change-ID: `generators`

## Story checklist
- [ ] 1. S070 — Add optional domain generators pack (email, URL, UUID, names) with shrinkers

## Story details
### S070: Add optional domain generators pack (email, URL, UUID, names) with shrinkers

Acceptance criteria:
- Generators produce values that pass simple validators.
- Shrinking reduces to simpler forms (shorter names, shorter domains, etc.).

Tests to add/update:
- Validator-based tests per generator.
- Determinism tests per generator.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
