# Delta for Plugins

## ADDED Requirements
### Requirement: Minimal permissions
Plugins MUST request the minimal permissions required to operate.

#### Scenario: Minimal permissions works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Deterministic output
Plugins MUST generate deterministic outputs and avoid nondeterministic file ordering.

#### Scenario: Deterministic output works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
