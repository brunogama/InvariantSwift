# Tasks: Plugins and trust: minimal permissions and deterministic generation

Change-ID: `plugins`

## Story checklist
- [ ] 1. S050 — Remove default network permission from build plugins; require explicit opt-in
- [ ] 2. S051 — Make plugin-generated outputs deterministic and stable

## Story details
### S050: Remove default network permission from build plugins; require explicit opt-in

Acceptance criteria:
- Package plugin permissions do not include network access by default.

Tests to add/update:
- CI check: grep Package.swift for network permissions and fail if present in default plugin.

### S051: Make plugin-generated outputs deterministic and stable

Acceptance criteria:
- Re-running generation with no input changes produces an empty git diff.

Tests to add/update:
- CI: run generation twice and assert output directories are identical.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
