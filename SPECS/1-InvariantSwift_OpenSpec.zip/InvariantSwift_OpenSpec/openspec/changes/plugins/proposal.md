# Proposal: Plugins and trust: minimal permissions and deterministic generation

Change-ID: `plugins`
Epic: `E050`

## Problem
Build plugins run during user builds. Requesting broad permissions (especially network) without an explicit opt-in erodes trust. Generated outputs must be deterministic to avoid noisy diffs.

## Goal
- Ensure plugins request only permissions they need (typically write-to-package-directory).
- Make generation deterministic (stable sorting, stable formatting, stable paths).
- Provide a clear opt-in mechanism for anything that would touch the network or external systems.

## Success metrics
- Plugin manifests contain no network permission by default.
- Regenerating output without input changes results in no diff.

## Stories
- S050 Plugin permissions minimal
- S051 Plugin deterministic output

## References
- Current spec(s):
  - `openspec/specs/plugins/spec.md`
- Change deltas:
  - `openspec/changes/plugins/specs/plugins/spec.md`
