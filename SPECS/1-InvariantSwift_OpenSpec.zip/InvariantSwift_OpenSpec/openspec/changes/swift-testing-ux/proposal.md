# Proposal: Swift Testing UX: native feeling integration and failure reporting

Change-ID: `swift-testing-ux`
Epic: `E060`

## Problem
If integration with Swift Testing feels foreign or produces noisy output, users will avoid the framework. Failures must show the minimal counterexample and a reproduction recipe.

## Goal
- Provide a Swift Testing adapter that maps InvariantSwift outcomes into a single clear test failure.
- Ensure failure output includes: minimal counterexample, iterations, discarded count, seed, and replay token.

## Success metrics
- A property failure yields a single Swift Testing failure with readable output.
- Reproduction recipe copy-paste reruns the same failure.

## Stories
- S060 Swift Testing adapter
- S032 Failure reporting recipe
- S061 Async/throws + timeouts

## References
- Current spec(s):
  - `openspec/specs/swift-testing-ux/spec.md`
- Change deltas:
  - `openspec/changes/swift-testing-ux/specs/swift-testing-ux/spec.md`
