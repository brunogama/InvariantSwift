# Delta for Swift Testing Ux

## ADDED Requirements
### Requirement: Swift Testing adapter
The system MUST provide a first-class adapter for Swift Testing with readable failure output.

#### Scenario: Swift Testing adapter works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Async/timeout
The runner MUST support async properties and timeouts with deterministic scheduling.

#### Scenario: Async/timeout works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
