# Design Notes: Swift Testing UX: native feeling integration and failure reporting

Change-ID: `swift-testing-ux`

## Context

Summarize key architectural decisions needed for this change.

## Decisions

- Decision 1: TBD

## Open questions

- What is the minimal API surface required to satisfy the spec?
- Where are the sharp edges in current implementation that could violate determinism?

## Risks

- Concurrency correctness under StrictConcurrency.
- Repro determinism across platforms.
