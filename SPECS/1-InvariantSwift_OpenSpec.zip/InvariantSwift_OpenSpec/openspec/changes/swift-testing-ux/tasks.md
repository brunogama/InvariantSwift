# Tasks: Swift Testing UX: native feeling integration and failure reporting

Change-ID: `swift-testing-ux`

## Story checklist
- [ ] 1. S060 — Implement Swift Testing adapter (Property -> @Test integration)
- [ ] 2. S061 — Support async/throws properties and configurable timeouts

## Story details
### S060: Implement Swift Testing adapter (Property -> @Test integration)

Acceptance criteria:
- A failing property produces one Swift Testing failure with the standardized report.
- A passing property produces no output.

Tests to add/update:
- Integration test using Swift Testing verifying the adapter compiles and runs.

### S061: Support async/throws properties and configurable timeouts

Acceptance criteria:
- Thrown errors are reported as a distinct failure reason.
- Timeouts produce a distinct timedOut reason.
- Determinism holds for the generation/shrink parts; timeout logic must not introduce nondeterminism in shrink ordering.

Tests to add/update:
- Unit test: predicate throws => outcome is threwError.
- Unit test: predicate exceeds timeout => outcome is timedOut.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
