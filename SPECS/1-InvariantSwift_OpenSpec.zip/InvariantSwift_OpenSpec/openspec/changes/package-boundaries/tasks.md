# Tasks: Package boundaries: split runtime core from macros and tooling

Change-ID: `package-boundaries`

## Story checklist
- [ ] 1. S040 — Split package targets (Core, Testing, MacroAPI, Macros)
- [ ] 2. S041 — Provide a full non-macro API (macro escape hatch)

## Story details
### S040: Split package targets (Core, Testing, MacroAPI, Macros)

Acceptance criteria:
- Depending only on `InvariantCore` does not build SwiftSyntax.
- Tests and examples compile using either macros or the explicit API (S041).

Tests to add/update:
- Build graph test (CI): Core target builds without SwiftSyntax.

### S041: Provide a full non-macro API (macro escape hatch)

Acceptance criteria:
- A user can write and run properties without importing macros.
- Macro and non-macro versions produce identical outcomes.

Tests to add/update:
- Example tests compiled in CI that do not import macros.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
