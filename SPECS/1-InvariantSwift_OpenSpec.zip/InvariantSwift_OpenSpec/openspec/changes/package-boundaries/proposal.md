# Proposal: Package boundaries: split runtime core from macros and tooling

Change-ID: `package-boundaries`
Epic: `E040`

## Problem
The runtime library should not pull in build-time dependencies (SwiftSyntax/macros). Mixing targets inflates build graphs and makes downstream integration fragile.

## Goal
- Split targets into at minimum: Core (runtime), Testing (Swift Testing integration), Macros (implementation), and MacroAPI (declarations).
- Ensure the Core target has zero dependency on SwiftSyntax.
- Keep all macro conveniences optional; everything must be doable without macros.

## Success metrics
- Users can depend only on the Core target without pulling in macro dependencies.
- Public API remains coherent across targets, with clear documentation about what belongs where.

## Stories
- S040 Split targets (core vs macros vs tooling)
- S041 Macro escape hatch

## References
- Current spec(s):
  - `openspec/specs/package-boundaries/spec.md`
- Change deltas:
  - `openspec/changes/package-boundaries/specs/package-boundaries/spec.md`
