# Delta for Package Boundaries

## ADDED Requirements
### Requirement: Core vs macros
The core PBT runtime MUST be usable without importing the macro target.

#### Scenario: Core vs macros works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Stable API surface
Public APIs MUST be minimized and versioned intentionally.

#### Scenario: Stable API surface works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
