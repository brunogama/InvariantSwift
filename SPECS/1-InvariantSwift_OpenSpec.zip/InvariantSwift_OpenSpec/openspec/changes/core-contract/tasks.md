# Tasks: Core Contract: Truthful runner, discards, and assumptions

Change-ID: `core-contract`

## Story checklist
- [ ] 1. S010 — Implement discard-aware runner loop (gaveUp, discard counts, reporting)
- [ ] 2. S011 — Stop using Gen.suchThat for assumptions; make suchThat safe and explicit
- [ ] 3. S012 — Introduce explicit assumption/discard API (assume, discard)
- [ ] 4. S025 — Remove unsafe casts and crash hazards in generator/shrink paths

## Story details
### S010: Implement discard-aware runner loop (gaveUp, discard counts, reporting)

Acceptance criteria:
- A property with an always-false assumption terminates with gaveUp after exceeding maxDiscarded.
- The predicate is never executed for discarded inputs (prove with a side effect).
- The final outcome includes discarded count and iteration count.

Tests to add/update:
- Unit test: always-false assumption => gaveUp.
- Unit test: assumption fails for some values => predicate called only for valid values.
- Golden test: failure output includes discarded count.

### S011: Stop using Gen.suchThat for assumptions; make suchThat safe and explicit

Acceptance criteria:
- There is no code path where a value that violates an assumption is passed to the predicate.
- `Gen.suchThat` no longer returns an invalid value after repeated attempts.
- Any filtering failure is observable (counted as discard or surfaced).

Tests to add/update:
- Unit test: `.suchThat` never produces invalid values.
- Unit test: the distribution bias is documented (not tested) and the API is clearly marked as filtering.

### S012: Introduce explicit assumption/discard API (assume, discard)

Acceptance criteria:
- A property can express assumptions inside the property body without generator filtering.
- Discards are counted and can trigger gaveUp.
- Discard reasons are optionally surfaced in debug output.

Tests to add/update:
- Unit test: property uses `assume(false)` for some inputs; runner counts discards and never executes failure logic for those.
- Unit test: enough discards triggers gaveUp.
- Unit test: discard reason is propagated to the outcome (if enabled).

### S025: Remove unsafe casts and crash hazards in generator/shrink paths

Acceptance criteria:
- No forced casts remain in `Sources/*` for core generator/shrink logic.
- Running the test suite under randomized properties does not crash due to internal type issues.

Tests to add/update:
- Unit test: shrink paths for `map`, `zip`, `apply`, `flatMap` do not crash.
- Fuzz-style test (deterministic seed) that composes generators and forces a failure to trigger shrinking.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
