# Delta for Core Contract

## ADDED Requirements
### Requirement: Assumption evaluation
The runner MUST evaluate assumptions before executing the property predicate.

#### Scenario: Assumption evaluation works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Discard accounting
The runner MUST count discarded inputs and return gaveUp when maxDiscarded is exceeded.

#### Scenario: Discard accounting works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
