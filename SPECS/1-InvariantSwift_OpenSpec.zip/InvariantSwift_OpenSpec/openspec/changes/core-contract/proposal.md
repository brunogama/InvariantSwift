# Proposal: Core Contract: Truthful runner, discards, and assumptions

Change-ID: `core-contract`
Epic: `E010`

## Problem
The current engine can test inputs that do not satisfy assumptions because assumptions are enforced via generator filtering instead of the runner. Discards are not counted and the runner cannot produce a proper gaveUp outcome.

## Goal
- Enforce assumptions in the runner (never run the property predicate on an input that fails assumptions).
- Track discards and return a gaveUp outcome when exceeding maxDiscarded.
- Provide an explicit API for assumptions/discards that does not rely on generator filtering.

## Out of scope
- Shrink tree design and shrink search (handled in E020).
- Replay tokens and seed splitting (handled in E030).

## Success metrics
- Unit tests prove the predicate is never executed for discarded inputs.
- Runner reports discarded count and produces gaveUp when configured limits are exceeded.
- Failure output includes discard statistics.

## Stories
- S010 Runner discard semantics
- S011 Stop using suchThat for assumptions
- S012 Assumption/discard API
- S025 Remove unsafe casts and crash hazards

## Notes for implementers (LLM/human)
- Prefer correctness and determinism over convenience.
- Keep behavior stable and observable (counts, outcomes, printed repro info).

## References
- Current spec(s):
  - `openspec/specs/core-contract/spec.md`
- Change deltas:
  - `openspec/changes/core-contract/specs/core-contract/spec.md`
