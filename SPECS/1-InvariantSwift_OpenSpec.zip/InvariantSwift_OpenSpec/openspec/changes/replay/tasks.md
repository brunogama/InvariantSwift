# Tasks: Determinism and replay: seed splitting, replay tokens, and stable failure recipes

Change-ID: `replay`

## Story checklist
- [ ] 1. S030 — Define and implement a seed splitting strategy for composite generators
- [ ] 2. S031 — Define replay token format capturing seed/config and minimal counterexample
- [ ] 3. S032 — Standardize failure output (minimal counterexample + copy-paste repro recipe)

## Story details
### S030: Define and implement a seed splitting strategy for composite generators

Acceptance criteria:
- `zip(genA, genB)` yields stable results even if internal implementation details of genA change their number of random draws (within reason).
- Shrinking and replay remain deterministic.

Tests to add/update:
- Determinism test: run a composed generator twice with the same seed and compare results.
- Regression test: modify an internal generator to consume extra random draws; composed generator output should remain stable (requires a test harness that simulates the change).

### S031: Define replay token format capturing seed/config and minimal counterexample

Acceptance criteria:
- A failure prints a replay token.
- Parsing a printed token and running again reproduces the same minimal counterexample.

Tests to add/update:
- Roundtrip encode/decode test.
- Integration test: record token from a failing run, rerun with token, compare minimal counterexample.

### S032: Standardize failure output (minimal counterexample + copy-paste repro recipe)

Acceptance criteria:
- Any failure prints a single report with all fields present.
- The report includes a copy-paste snippet that re-runs the property with the replay token.

Tests to add/update:
- Golden tests for failure output formatting.

## Definition of done
- All checklist items completed.
- Specs updated (current specs reflect the new truth).
- Tests pass and coverage for new behavior exists.
- Deterministic repro info is available for failures.
