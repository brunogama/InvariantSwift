# Delta for Replay

## ADDED Requirements
### Requirement: Seed splitting
The RNG MUST use a deterministic seed-splitting strategy per iteration.

#### Scenario: Seed splitting works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement

### Requirement: Replay token
The system MUST emit a replay token sufficient to reproduce a failing case exactly.

#### Scenario: Replay token works
- WHEN the feature is exercised
- THEN the behavior SHALL match the requirement
