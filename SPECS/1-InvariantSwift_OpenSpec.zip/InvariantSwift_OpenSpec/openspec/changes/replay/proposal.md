# Proposal: Determinism and replay: seed splitting, replay tokens, and stable failure recipes

Change-ID: `replay`
Epic: `E030`

## Problem
Even with a fixed seed, composite generators and shrinking can become unintentionally coupled or unstable unless RNG usage is disciplined. Failure output must include a stable reproduction recipe that re-runs the exact failing case and shrink result.

## Goal
- Define a seed splitting strategy so composite generators can be deterministic without accidental coupling.
- Introduce a replay token format that fully captures what is needed to reproduce a failure.
- Make failure output include a copy-paste recipe (seed/config/token).

## Success metrics
- Same seed/config always produce identical generation streams and shrink results.
- A replay token reproduced in a separate run yields the same minimal counterexample.

## Stories
- S030 Seed splitting strategy
- S031 Replay token format
- S032 Failure reporting recipe

## References
- Current spec(s):
  - `openspec/specs/replay/spec.md`
- Change deltas:
  - `openspec/changes/replay/specs/replay/spec.md`
