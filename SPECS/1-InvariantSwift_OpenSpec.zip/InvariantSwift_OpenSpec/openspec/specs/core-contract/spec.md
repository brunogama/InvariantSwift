# Core Contract Specification

## Purpose
## Problem

## Requirements
### Requirement: Enforce assumptions in the runner never run the property pre
The system SHALL implement: Enforce assumptions in the runner (never run the property predicate on an input that fails assumptions).

#### Scenario: Enforce assumptions in the runner never run the property pre works end-to-end
- WHEN a developer uses the core-contract capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly

### Requirement: Track discards and return a gaveUp outcome when exceeding ma
The system SHALL implement: Track discards and return a gaveUp outcome when exceeding maxDiscarded.

#### Scenario: Track discards and return a gaveUp outcome when exceeding ma works end-to-end
- WHEN a developer uses the core-contract capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly

### Requirement: Provide an explicit API for assumptionsdiscards that does no
The system SHALL implement: Provide an explicit API for assumptions/discards that does not rely on generator filtering.

#### Scenario: Provide an explicit API for assumptionsdiscards that does no works end-to-end
- WHEN a developer uses the core-contract capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly
