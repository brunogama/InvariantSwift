# Package Boundaries Specification

## Purpose
## Problem

## Requirements
### Requirement: Split targets into at minimum Core runtime Testing Swift Tes
The system SHALL implement: Split targets into at minimum: Core (runtime), Testing (Swift Testing integration), Macros (implementation), and MacroAPI (declarations).

#### Scenario: Split targets into at minimum Core runtime Testing Swift Tes works end-to-end
- WHEN a developer uses the package-boundaries capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly

### Requirement: Ensure the Core target has zero dependency on SwiftSyntax
The system SHALL implement: Ensure the Core target has zero dependency on SwiftSyntax.

#### Scenario: Ensure the Core target has zero dependency on SwiftSyntax works end-to-end
- WHEN a developer uses the package-boundaries capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly

### Requirement: Keep all macro conveniences optional everything must be doab
The system SHALL implement: Keep all macro conveniences optional; everything must be doable without macros.

#### Scenario: Keep all macro conveniences optional everything must be doab works end-to-end
- WHEN a developer uses the package-boundaries capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly
