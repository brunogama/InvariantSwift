# Replay & Determinism Specification

## Purpose
## Problem

## Requirements
### Requirement: Define a seed splitting strategy so composite generators can
The system SHALL implement: Define a seed splitting strategy so composite generators can be deterministic without accidental coupling.

#### Scenario: Define a seed splitting strategy so composite generators can works end-to-end
- WHEN a developer uses the replay capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly

### Requirement: Introduce a replay token format that fully captures what is
The system SHALL implement: Introduce a replay token format that fully captures what is needed to reproduce a failure.

#### Scenario: Introduce a replay token format that fully captures what is works end-to-end
- WHEN a developer uses the replay capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly

### Requirement: Make failure output include a copypaste recipe seedconfigtok
The system SHALL implement: Make failure output include a copy-paste recipe (seed/config/token).

#### Scenario: Make failure output include a copypaste recipe seedconfigtok works end-to-end
- WHEN a developer uses the replay capability as specified
- THEN the framework behaves deterministically and reports outcomes clearly
