# OpenSpec Workspace

- `specs/` is the current truth.
- `changes/` contains proposed/active work.
- `archive/` contains completed changes.

Start by reading:

1. `openspec/AGENTS.md`
2. `openspec/project.md`
3. `openspec/specs/`
