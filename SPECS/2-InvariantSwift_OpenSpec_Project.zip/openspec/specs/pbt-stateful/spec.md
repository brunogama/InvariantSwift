# Stateful Testing Specification

## Purpose
Define model-based/stateful property testing (commands, state model, postconditions, shrinking sequences).

## Requirements

### Requirement: Commands Define Preconditions and Transitions
A command MUST define a precondition, state transition, and postcondition.

#### Scenario: Invalid commands are discarded
- GIVEN a command whose precondition fails in state S
- WHEN generating command sequences
- THEN the command is discarded and does not execute

### Requirement: Command Sequences Shrink
Failing command sequences MUST be shrinkable (length and content).

#### Scenario: Sequence shrinks to minimal failing prefix
- GIVEN a failing command sequence
- WHEN shrinking
- THEN the minimal failing sequence is returned

## Known Issues
- Advanced stateful/macro surfaces exist, but the core discard/shrink semantics need to be corrected first.
