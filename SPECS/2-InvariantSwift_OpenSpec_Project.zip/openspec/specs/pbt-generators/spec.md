# Generators Specification

## Purpose
Document the generator catalog and composition rules (map/flatMap/zip/oneOf/frequency) and quality expectations.

## Requirements

### Requirement: Generator Composition Preserves Determinism
Combinators MUST not break determinism under a fixed seed.

#### Scenario: zip is deterministic
- GIVEN two generators A and B
- WHEN zipping under seed S twice
- THEN results match

### Requirement: Domain Generators Are Optional
Real-world generators (email, URL, names, addresses) SHOULD live in an optional target to avoid bloating the core.

#### Scenario: Core remains minimal
- GIVEN a consumer that imports only the core product
- WHEN building
- THEN no domain generator dependencies are pulled in

## Known Issues
- RNG splitting for independent streams is not consistently modeled, which can couple composite generator results.
