# Swift Testing Integration Specification

## Purpose
Define how InvariantSwift integrates with Apple's Swift Testing framework (assertion reporting, parameterization style, async).

## Requirements

### Requirement: Single Failure Report per Property
A property test SHOULD report a single failure containing the minimal counterexample and reproduction data.

#### Scenario: Property fails once with minimal example
- GIVEN a property that fails for some inputs
- WHEN executed under Swift Testing
- THEN the test reports one failure that includes the minimal counterexample and seed

### Requirement: Async Properties Are Supported
The integration MUST support evaluating async properties.

#### Scenario: Async predicate is awaited
- GIVEN an async predicate
- WHEN running a property
- THEN the predicate is awaited for each iteration

## Known Issues
- The core predicate type is non-throwing and non-async in parts of the codebase, limiting integration fidelity.
