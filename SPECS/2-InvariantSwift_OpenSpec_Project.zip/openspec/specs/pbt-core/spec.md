# PBT Core Specification

## Purpose
Define the current behavior, constraints, and known deficiencies of InvariantSwift's property-based testing core (Gen/Shrink/Property/Runner).

## Requirements

### Requirement: Deterministic Generation
The system MUST produce identical samples for a given generator when initialized with the same seed and size.

#### Scenario: Same seed yields the same sample
- GIVEN a generator G
- AND seed S
- AND size Z
- WHEN a sample is drawn from G with (S,Z) two times
- THEN the two samples are equal

### Requirement: Runner Evaluates a Predicate
The system MUST evaluate a predicate over generated values for a configured number of iterations.

#### Scenario: Property holds for all iterations
- GIVEN a predicate P that returns true for all inputs
- WHEN the runner executes N iterations
- THEN the result is success

### Requirement: Assumptions Are Represented As Discards
Current behavior: assumptions are expressed by filtering generation (`Gen.suchThat`) rather than runner-level discards.

#### Scenario: Filtered generation can return invalid values
- GIVEN a generator filtered by a predicate that rarely holds
- WHEN the generator retries a bounded number of times
- THEN it may return a value that does not satisfy the filter

## Known Issues
- The runner does not track discarded cases and cannot report a proper "gave up" result.
