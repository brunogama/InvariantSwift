# Macros Specification

## Purpose
Define the macro surface (e.g., @PropertyTest, @Arbitrary, @Gen, @Reproduce) and the constraints for predictable codegen.

## Requirements

### Requirement: Macro Expansion Is Transparent
Macro expansions MUST produce debuggable code that maps clearly to user-written tests.

#### Scenario: Expanded test includes a single runner call
- GIVEN a function annotated with @PropertyTest
- WHEN the macro expands
- THEN the expanded code contains exactly one call into the core runner

### Requirement: Macro Expansion Is Stable
Under the same toolchain, macro expansion MUST be deterministic.

#### Scenario: Expansion yields identical source across runs
- GIVEN identical input source
- WHEN expanding twice
- THEN the expanded source is identical

## Known Issues
- Macro features are ahead of core semantics (discards/shrinking), creating a mismatch between advertised and actual behavior.
