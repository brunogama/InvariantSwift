# Shrinking Specification

## Purpose
Describe the current shrinking behavior and the invariants required for reliable counterexample minimization.

## Requirements

### Requirement: Shrink Produces Candidate Values
The system MUST provide a way to produce simpler candidates from a value.

#### Scenario: Integer shrinking produces smaller magnitudes
- GIVEN a shrinker for Int
- WHEN shrinking the value 100
- THEN at least one candidate has absolute value < 100

### Requirement: Shrink Search Is Deterministic
Given identical inputs (seed, shrink ordering), the shrink search MUST yield the same minimal counterexample.

#### Scenario: Repeat shrink returns the same minimal value
- GIVEN a failing value V and its shrink candidates
- WHEN shrink is run twice under the same ordering
- THEN the minimal found value is equal

## Known Issues
- `Shrink.contramap` is not a valid contramap and may repeat the same value.
- `Shrink.flatMap` is stubbed, causing `Gen.flatMap` to lose shrinking.
- Shrink search is greedy-first and may not find minimal counterexamples.
