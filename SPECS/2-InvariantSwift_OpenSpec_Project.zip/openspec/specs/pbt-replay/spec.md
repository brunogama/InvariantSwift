# Replay Specification

## Purpose
Define how failing cases are reproduced deterministically (seed, size progression, and shrink trace).

## Requirements

### Requirement: Failure Output Includes Reproduction Data
On failure, the system MUST report a reproduction recipe that is sufficient to rerun the same failure.

#### Scenario: Failure includes seed and minimal example
- GIVEN a failing property
- WHEN the run completes
- THEN the output includes seed and the minimal counterexample value

### Requirement: Replay Reproduces the Same Failure
The system MUST allow rerunning a property with a provided replay token to reproduce the same failure.

#### Scenario: Replay token reproduces
- GIVEN a failing run that emitted a replay token
- WHEN the property is rerun using that token
- THEN the property fails with the same minimal counterexample

## Known Issues
- Replay exists at macro level in the repository but the runner does not guarantee full reproduction of size progression and shrink path.
