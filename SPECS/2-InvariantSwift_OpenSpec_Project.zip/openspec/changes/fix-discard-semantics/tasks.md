## 1. Runner discard accounting
- [ ] 1.1 Introduce a runner-level notion of discard (assumption failed)
- [ ] 1.2 Track discarded count and stop when `maxDiscarded` is exceeded
- [ ] 1.3 Return a `gaveUp` result with discarded/iteration metadata

## 2. Remove unsafe suchThat usage for assumptions
- [ ] 2.1 Deprecate or restrict `Gen.suchThat` for use as assumptions
- [ ] 2.2 Update `Property.filter` to register an assumption predicate instead of filtering generation

## 3. Tests
- [ ] 3.1 Add unit tests demonstrating old behavior (invalid value can slip through) and new behavior (discarded)
- [ ] 3.2 Add integration test ensuring `gaveUp` is emitted when assumptions are too restrictive

## 4. Developer UX
- [ ] 4.1 Failure output includes discarded count and gives guidance (increase maxDiscarded or adjust assumption)
