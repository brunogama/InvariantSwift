# OpenSpec Change Proposals — More Features

Copy these folders into your repo under `openspec/changes/`.

- `async-throws-predicate-runner` — Add async/throws predicates and runner support (`pbt-core`)
- `timeouts-cancellation` — Add per-property timeouts and cooperative cancellation (`pbt-core`)
- `parallel-checking` — Parallel property checking with stable seeding (`pbt-core`)
- `seed-splitting-spec` — Define seed splitting and replay token schema (`pbt-replay`)
- `collection-shrinking-v2` — Add chunk-removal shrinking for collections (delta-debugging style) (`pbt-shrinking`)
- `float-generation-shrinking` — Robust Float/Double generation and shrinking (`pbt-generators`)
- `crash-isolation-macos-subprocess` — Crash isolation via subprocess runner on macOS (`pbt-core`)
- `json-report-schema` — Machine-readable JSON reporting for runs (`pbt-core`)
- `property-combinators` — Property composition combinators (and/or/implication) (`pbt-core`)
- `stateful-command-shrinking` — Stateful testing: shrink command sequences (`pbt-stateful`)
