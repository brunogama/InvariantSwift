# Tasks

- [ ] Add optional runner mode: subprocess isolation (macOS only)
- [ ] Define IPC protocol: send seed+iteration index; receive pass/fail and any output
- [ ] Ensure deterministic minimization by replaying in subprocess during shrinking
- [ ] Add integration tests that deliberately crash and confirm the main process survives
