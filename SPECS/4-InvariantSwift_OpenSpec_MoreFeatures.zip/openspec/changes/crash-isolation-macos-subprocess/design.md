# Design

## Key decisions
- Isolation is opt-in and only enabled on macOS host environments
- Subprocess runner uses an embedded helper executable

## Open questions
- How to package helper executable in SwiftPM products cleanly?
- Should this be a separate target to avoid iOS impact?
