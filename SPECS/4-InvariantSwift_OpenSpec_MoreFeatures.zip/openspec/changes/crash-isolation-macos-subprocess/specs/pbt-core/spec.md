# Spec Delta — pbt-core

## ADDED Requirements

### Requirement: CORE-CRASH-001 — Crash isolation
        When isolation is enabled, fatal crashes in a test case MUST not crash the parent process.

        #### Scenario: fatalError isolated
- **Given:** a property that triggers fatalError for some input
- **When:** executed with isolation enabled
- **Then:** the run reports failure and the test process stays alive
