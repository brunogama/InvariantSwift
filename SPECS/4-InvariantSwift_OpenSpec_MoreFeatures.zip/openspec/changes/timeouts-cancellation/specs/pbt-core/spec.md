# Spec Delta — pbt-core

## ADDED Requirements

### Requirement: CORE-TIME-001 — Timeouts
        The framework MUST support timeouts for async property evaluation.

        #### Scenario: Timeout triggers
- **Given:** an async predicate that never completes
- **When:** executed with a timeout
- **Then:** the property result is failure with reason `timedOut`

### Requirement: CORE-CANCEL-001 — Cancellation
        The framework MUST support cooperative cancellation and return a deterministic cancelled outcome.

        #### Scenario: Run cancelled
- **Given:** a running property check
- **When:** the caller cancels the task
- **Then:** the run terminates and reports cancellation deterministically
