# Tasks

- [ ] Add PropertyConfig.timeout (Duration) and RunnerConfig.globalTimeout
- [ ] Implement timeout handling for async predicates using Task + clock
- [ ] Return FailureReason.timedOut with elapsed time
- [ ] Ensure shrinking respects timeouts (abort shrink search when time budget exhausted)
- [ ] Add tests for timeout behavior and cancellation
