# Design

## Key decisions
- Timeout applies per test case evaluation, not entire run (unless globalTimeout set)
- Shrinking has a separate shrinkTimeBudget derived from remaining time

## Open questions
- Should timeout be available for sync predicates (wall clock)?
- What is the default timeout (if any)?
