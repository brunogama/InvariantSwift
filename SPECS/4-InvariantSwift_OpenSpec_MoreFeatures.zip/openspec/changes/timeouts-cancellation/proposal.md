---
id: timeouts-cancellation
title: Add per-property timeouts and cooperative cancellation
capability: pbt-core
status: proposed
---

# Add per-property timeouts and cooperative cancellation

## Summary
Support per-property timeouts for async predicates and allow cancelling long-running runs deterministically.

## Motivation
- Improve correctness, determinism, and developer trust in InvariantSwift.
- Provide a narrowly-scoped, testable increment aligned with the PBT contract.

## Scope
- Implement the requirements in the spec delta for `pbt-core`.
- Add tests and documentation required for long-term maintenance.

## Non-goals
- No new experimental features beyond the requirements listed below.
- No breaking API changes unless explicitly listed in the spec delta.

## Risks
- Performance regressions if the implementation is naïve.
- Behavioral changes that alter existing shrink/minimization outcomes.

## Acceptance
- All scenarios in the spec delta pass.
- CI passes on supported platforms.
