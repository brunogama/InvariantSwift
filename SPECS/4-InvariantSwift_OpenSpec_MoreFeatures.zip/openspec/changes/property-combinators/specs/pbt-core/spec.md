# Spec Delta — pbt-core

## ADDED Requirements

### Requirement: CORE-COMB-001 — And/Or/Implies
        The framework MUST support composing properties with and/or/implication semantics.

        #### Scenario: Implication discards
- **Given:** property A implies B
- **When:** A is false for an input
- **Then:** the case is discarded and does not count as a pass
