# Design

## Key decisions
- and/or are evaluated left-to-right; implication discards when premise is false (counts as discard)
- Failure output includes which sub-property failed

## Open questions
- Should composition preserve shrinkers per sub-property or wrap into a combined shrink tree?
