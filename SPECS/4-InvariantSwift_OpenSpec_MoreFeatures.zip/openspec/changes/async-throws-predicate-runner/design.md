# Design

## Key decisions
- Prefer new overloads over breaking signature changes where possible
- FailureReason.threwError becomes reachable via throwing predicates
- Async runner must not block main thread; use Task and timeouts (separate change)

## Open questions
- Should async properties be allowed on Linux without Swift Testing?
- How to format thrown errors for stable snapshots?
