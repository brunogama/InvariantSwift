# Spec Delta — pbt-core

## ADDED Requirements

### Requirement: CORE-ASYNC-001 — Async predicates
        The framework MUST allow properties with `async` predicates.

        #### Scenario: Async property success
- **Given:** a property with an async predicate that returns true
- **When:** the property is executed
- **Then:** the run completes as success

#### Scenario: Async property failure
- **Given:** a property with an async predicate that returns false for some input
- **When:** the property is executed
- **Then:** the run reports a failing minimal counterexample

### Requirement: CORE-THROW-001 — Throwing predicates
        The framework MUST capture thrown errors as failures with stable formatting.

        #### Scenario: Throwing predicate captured
- **Given:** a property whose predicate throws for some input
- **When:** the property is executed
- **Then:** the result is failure with reason `threwError` including the error description
