# Tasks

- [ ] Introduce PropertyPredicate variants: sync, throwing, async, asyncThrowing
- [ ] Update PropertyRunner to execute predicates with proper error capture
- [ ] Ensure failure reasons include thrown error details deterministically
- [ ] Add unit tests for sync/throws/async/async-throws properties
- [ ] Update macro expansion to call the correct runner entrypoint
