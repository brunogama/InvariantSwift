# Tasks

- [ ] Add Double/Float generator modes: finiteOnly, allowInfinity, allowNaN
- [ ] Add shrinkers that move toward 0 with exponent/mantissa simplification
- [ ] Provide comparison helpers/tolerances for properties
- [ ] Add tests for determinism across platforms
