# Design

## Key decisions
- Default generator is finiteOnly to avoid accidental NaN poisoning
- Shrinker never produces NaN unless input is NaN and mode allows it

## Open questions
- Should approximate equality helpers live in core or assertions module?
