# Spec Delta — pbt-generators

## ADDED Requirements

### Requirement: GEN-FLOAT-001 — Finite defaults
        Default Float/Double generators MUST produce finite values only.

        #### Scenario: Finite by default
- **Given:** a default Double generator
- **When:** sampling 10k values
- **Then:** no value is NaN or infinity

### Requirement: SHRINK-FLOAT-001 — Stable shrinking
        Float/Double shrinking MUST be deterministic and converge toward 0.

        #### Scenario: Shrinks toward zero
- **Given:** a failing input 12345.678
- **When:** shrinking runs
- **Then:** candidates approach 0 with decreasing magnitude
