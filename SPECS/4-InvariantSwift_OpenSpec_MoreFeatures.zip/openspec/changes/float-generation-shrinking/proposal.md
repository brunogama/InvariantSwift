---
id: float-generation-shrinking
title: Robust Float/Double generation and shrinking
capability: pbt-generators
status: proposed
---

# Robust Float/Double generation and shrinking

## Summary
Define Float/Double generators and shrinkers that handle NaN/inf/subnormals deterministically and avoid flaky comparisons.

## Motivation
- Improve correctness, determinism, and developer trust in InvariantSwift.
- Provide a narrowly-scoped, testable increment aligned with the PBT contract.

## Scope
- Implement the requirements in the spec delta for `pbt-generators`.
- Add tests and documentation required for long-term maintenance.

## Non-goals
- No new experimental features beyond the requirements listed below.
- No breaking API changes unless explicitly listed in the spec delta.

## Risks
- Performance regressions if the implementation is naïve.
- Behavioral changes that alter existing shrink/minimization outcomes.

## Acceptance
- All scenarios in the spec delta pass.
- CI passes on supported platforms.
