# Design

## Key decisions
- Replay token is versioned (v1) with forward-compatible fields
- Seed splitting is pure and deterministic and does not depend on platform RNG

## Open questions
- Should shrinkTrace be included by default or only when enabled?
- Preferred encoding: base64url(JSON) vs compact binary?
