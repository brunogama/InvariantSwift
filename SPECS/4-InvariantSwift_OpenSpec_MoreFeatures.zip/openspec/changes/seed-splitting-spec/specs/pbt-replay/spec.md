# Spec Delta — pbt-replay

## ADDED Requirements

### Requirement: REPLAY-001 — Replay token
        The framework MUST emit a replay token that deterministically reproduces a failure.

        #### Scenario: Replay reproduces
- **Given:** a failure with a replay token
- **When:** the property is re-run with that token
- **Then:** the same minimal counterexample is produced

### Requirement: REPLAY-002 — Versioning
        Replay tokens MUST include a version field and remain parseable across minor releases.

        #### Scenario: Old token parses
- **Given:** a token emitted by a previous minor release
- **When:** decoded
- **Then:** the framework successfully replays or reports a clear unsupported-version error
