# Tasks

- [ ] Define ReplayToken schema: seed, sizeSchedule, iterationCount, shrinkTrace (optional)
- [ ] Implement seed splitting utility (SplitMix64 or equivalent)
- [ ] Ensure Gen.zip/flatMap/apply use split streams instead of shared RNG (where required)
- [ ] Add encoding/decoding tests for replay token stability
