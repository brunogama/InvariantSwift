---
id: seed-splitting-spec
title: Define seed splitting and replay token schema
capability: pbt-replay
status: proposed
---

# Define seed splitting and replay token schema

## Summary
Standardize seed splitting across combinators and define a stable replay token schema that survives internal refactors.

## Motivation
- Improve correctness, determinism, and developer trust in InvariantSwift.
- Provide a narrowly-scoped, testable increment aligned with the PBT contract.

## Scope
- Implement the requirements in the spec delta for `pbt-replay`.
- Add tests and documentation required for long-term maintenance.

## Non-goals
- No new experimental features beyond the requirements listed below.
- No breaking API changes unless explicitly listed in the spec delta.

## Risks
- Performance regressions if the implementation is naïve.
- Behavioral changes that alter existing shrink/minimization outcomes.

## Acceptance
- All scenarios in the spec delta pass.
- CI passes on supported platforms.
