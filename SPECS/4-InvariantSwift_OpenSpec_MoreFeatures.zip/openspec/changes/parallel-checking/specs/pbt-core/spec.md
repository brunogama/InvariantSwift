# Spec Delta — pbt-core

## ADDED Requirements

### Requirement: CORE-PAR-001 — Deterministic parallelism
        When parallelism is enabled, results MUST be identical to serial execution for the same seed/config.

        #### Scenario: Parallel matches serial
- **Given:** a property with fixed seed and config
- **When:** executed with parallelism=1 and parallelism=4
- **Then:** the minimal counterexample and replay token are identical
