# Tasks

- [ ] Introduce RunnerConfig.parallelism (Int) with default 1
- [ ] Implement deterministic seed splitting per worker and per iteration
- [ ] Aggregate failures deterministically (first failing iteration by global iteration order)
- [ ] Ensure shrinking runs single-threaded to keep minimality stable
- [ ] Add tests verifying identical outcomes between parallelism=1 and parallelism>1
