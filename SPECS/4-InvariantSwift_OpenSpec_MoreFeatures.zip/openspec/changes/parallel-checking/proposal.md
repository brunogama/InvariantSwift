---
id: parallel-checking
title: Parallel property checking with stable seeding
capability: pbt-core
status: proposed
---

# Parallel property checking with stable seeding

## Summary
Add optional parallel execution of test iterations while preserving determinism via seed splitting and stable scheduling.

## Motivation
- Improve correctness, determinism, and developer trust in InvariantSwift.
- Provide a narrowly-scoped, testable increment aligned with the PBT contract.

## Scope
- Implement the requirements in the spec delta for `pbt-core`.
- Add tests and documentation required for long-term maintenance.

## Non-goals
- No new experimental features beyond the requirements listed below.
- No breaking API changes unless explicitly listed in the spec delta.

## Risks
- Performance regressions if the implementation is naïve.
- Behavioral changes that alter existing shrink/minimization outcomes.

## Acceptance
- All scenarios in the spec delta pass.
- CI passes on supported platforms.
