# Design

## Key decisions
- Parallelism affects generation+evaluation only; shrinking stays serial
- Global iteration order is defined by iterationIndex regardless of worker scheduling

## Open questions
- Should parallel checking be disabled by default on iOS simulators?
- How to expose worker progress in Swift Testing output?
