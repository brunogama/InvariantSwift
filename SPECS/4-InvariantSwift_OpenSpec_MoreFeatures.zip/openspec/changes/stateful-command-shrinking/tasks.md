# Tasks

- [ ] Define CommandSequence representation with deterministic ordering
- [ ] Implement shrinker: remove chunks, then shrink individual commands
- [ ] Ensure postconditions are preserved and shrink search remains deterministic
- [ ] Add example model (e.g., stack) and tests verifying minimal sequences
