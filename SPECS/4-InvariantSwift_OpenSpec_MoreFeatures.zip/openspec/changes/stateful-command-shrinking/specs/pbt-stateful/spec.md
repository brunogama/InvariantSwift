# Spec Delta — pbt-stateful

## ADDED Requirements

### Requirement: STATE-SEQ-001 — Command sequence shrinking
        Stateful testing MUST shrink failing command sequences to a minimal reproducer.

        #### Scenario: Minimizes sequence
- **Given:** a failing sequence of 20 commands
- **When:** shrinking runs
- **Then:** a minimal failing sequence is produced (often far smaller than 20)
