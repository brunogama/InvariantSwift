# Design

## Key decisions
- Sequence shrink order uses chunk removal first (like collections v2)
- Command shrink is provided by each command type

## Open questions
- Should the framework auto-derive command shrinkers for enums/structs?
