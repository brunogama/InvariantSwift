# Tasks

- [ ] Define JSON schema v1 (documented in spec delta)
- [ ] Implement encoder for RunReport and FailureReport
- [ ] Add runner API to export a report and optional CLI emission
- [ ] Add tests for schema stability and field presence
