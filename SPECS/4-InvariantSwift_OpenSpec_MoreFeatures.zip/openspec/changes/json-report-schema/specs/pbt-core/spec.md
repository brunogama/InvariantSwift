# Spec Delta — pbt-core

## ADDED Requirements

### Requirement: CORE-REPORT-001 — JSON report
        The framework MUST be able to emit a versioned JSON report for each run.

        #### Scenario: Report includes replay
- **Given:** a failing property run
- **When:** a JSON report is emitted
- **Then:** the report includes replay token and minimal counterexample encoding
