# Design

## Key decisions
- JSON schema is stable and versioned
- All durations are encoded in milliseconds as integers

## Open questions
- Where should reports be written by default (tmp vs user provided)?
