# Design

## Key decisions
- Candidate order: remove largest chunks first, then smaller, then element-wise shrink
- Dictionary order uses stable sorting of keys to avoid hashing nondeterminism

## Open questions
- How to handle Set shrinking deterministically?
