# Spec Delta — pbt-shrinking

## ADDED Requirements

### Requirement: SHRINK-COLL-001 — Chunk removal
        Collection shrinkers MUST attempt chunk removal before element-wise shrinking.

        #### Scenario: Array shrinks by deletion
- **Given:** a failing property on an array
- **When:** shrinking runs
- **Then:** the minimal array is achieved primarily via deletions when possible
