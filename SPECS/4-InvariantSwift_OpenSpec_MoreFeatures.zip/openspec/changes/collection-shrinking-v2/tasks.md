# Tasks

- [ ] Introduce shrink strategies for Array: chunk removal (halve), then element shrink
- [ ] Add Dictionary shrink by removing key subsets, then shrinking values
- [ ] Guarantee deterministic candidate order
- [ ] Add tests for minimality and determinism on known failing properties
