# Change: add-benchmark-suite

    ## Why
    PBT is performance-sensitive. Without benchmarks, shrinking and generators can regress unnoticed.

    ## What Changes
    - Add a benchmark suite measuring:
  - generator throughput for common types
  - shrink search time on representative failing predicates
  - replay speed (including regression-bank runs when enabled)
- Add CI performance guardrails (non-blocking initially).

    ## Impact
    - Provides performance baselines; helps prioritize optimizations realistically.

    ## Non-Goals
    - N/A

    ## Risks
    - Benchmarks can be flaky in CI; guardrails must tolerate variance.
