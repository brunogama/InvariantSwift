# Tasks

## Implementation
- [ ] 1. Create `Benchmarks/` target or SwiftPM plugin-based bench runner
- [ ] 2. Add baseline benchmarks for Int, String, Array<Int>, Dictionary<String,Int>
- [ ] 3. Add shrink benchmarks with fixed failing predicates
- [ ] 4. Document how to run benchmarks locally; add CI job non-blocking

## Validation
- [ ] Run unit tests for affected targets
- [ ] Add/adjust tests to cover new requirements and scenarios
- [ ] Ensure failure output includes replay token when applicable
