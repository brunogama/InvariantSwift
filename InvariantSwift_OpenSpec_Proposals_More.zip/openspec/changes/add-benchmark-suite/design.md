# Design Notes

- Avoid strict time thresholds in CI at first; record results and track trends.
- Keep benchmarks deterministic: fixed seeds and fixed inputs.
